/*
 * @author duong
 * @date Jul 12, 2021
 * @version 1.0

*/

package exercise1;

public enum Operator {
	CONG, TRU, NHAN, CHIA, SOMU, BANG;
	
}

