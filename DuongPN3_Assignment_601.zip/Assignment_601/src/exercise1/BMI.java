/*
 * @author duong
 * @date Jul 12, 2021
 * @version 1.0

*/

package exercise1;

public enum BMI {
	SUBSTANDARD, STANDARD, OVERWIGHT, FAT, VERYFAT;
}
